﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Prueba_MVC_AP.Models
{
    public class ClsReloj
    {
        //int hora;
       // int minuto;
    }
}